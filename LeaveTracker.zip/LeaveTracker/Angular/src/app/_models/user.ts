﻿export class User {
    id: string;
    name: string;
    password: string;
    email: string;
    role: string;
    token: string;
}