﻿export class Leave_Request {
    id: string;
    fk_userid : string;  
    from_date : string
    to_date : string
    leave_reason : string
    status : string
    approved_byid : string
    approved_date :string
    approval_comments : string
    submitted_id : string
}