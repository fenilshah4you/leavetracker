﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { AccountService, AlertService } from '@app/_services';

@Component({ templateUrl: 'add-edit.component.html' })
export class AddEditComponent implements OnInit {
    form: FormGroup;
    id: string;
    isAddMode: boolean;
    loading = false;
    submitted = false;
    managers = null;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private accountService: AccountService,
        private alertService: AlertService
    ) {}

    ngOnInit() {
        this.id = this.route.snapshot.params['id'];
        this.isAddMode = !this.id; 

        this.form = this.formBuilder.group({
            fk_userid: ['', Validators.required],
            from_date: ['', Validators.required],
            to_date: ['', Validators.required],
            leave_reason: ['', Validators.required]
        });

        this.accountService.getAllManager()
        .pipe(first())
        .subscribe(managers => this.managers = managers['users']);

        // if (!this.isAddMode) {
        //     this.accountService.getById(this.id)
        //         .pipe(first())
        //         .subscribe(x => {
        //             this.f.fk_userid.setValue(x.fk_userid);
        //             this.f.from_date.setValue(x.from_date);
        //             this.f.to_date.setValue(x.to_date);
        //             this.f.id.setValue(x.id);
        //         });
        // }
    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    onSubmit() {
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.form.invalid) {
            return;
        }

        this.loading = true;
        if (this.isAddMode) {
            this.createLR();
        }  
    }

    private createLR() {
        this.accountService.createLeaveRequest(this.form.value)
            .pipe(first())
            .subscribe(
                data => {
                    this.alertService.success('Leave Request added successfully', { keepAfterRouteChange: true });
                    this.router.navigate(['.', { relativeTo: this.route }]);
                },
                error => {
                    if(error == "UNKNOWN"){
                    this.alertService.error("Leave request already exists for this user for the same day");
                }else{
                    this.alertService.error(error)
                }
                    this.loading = false;
                });
    }

     
}