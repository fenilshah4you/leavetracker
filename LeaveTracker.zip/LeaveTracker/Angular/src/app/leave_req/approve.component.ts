﻿import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';

import { AccountService } from '@app/_services';
import { HttpParams } from '@angular/common/http';

@Component({ templateUrl: 'approve.component.html' })
export class ApproveComponent implements OnInit {
    leaves_appr = null;

    constructor(private accountService: AccountService) {}

    ngOnInit() {
        this.test()  
    }

    test(){
        this.accountService.getAllApprovalRequestByUserId()
            .pipe(first())
            .subscribe(lrData => this.leaves_appr = lrData['lrData']);
    }

    approveReq(id: string) {
        // const user = this.leaves_appr.find(x => x.id === id);
        // user.isDeleting = true;
        var params = {id:'',approval_comments:"",status:""};
        params.id = id;
        params.approval_comments = "Ok"
        params.status = "Approved"
       
        this.approve_reject(params)
        
    }

    

    rejectReq(id: string) {
        // const user = this.leaves_appr.find(x => x.id === id);
        // user.isDeleting = true;
        var params = {id:'',approval_comments:"",status:""};
        params.id = id;
        params.approval_comments = "Not Ok"
        params.status = "Rejected"
        this.approve_reject(params)
    }

    approve_reject(params: any){
        this.accountService.approveReject(params)
            .pipe(first())
            .subscribe(() => {
                this.test() 
            });
    }
}