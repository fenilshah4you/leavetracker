from sqlite3 import Date
#from xmlrpc.client import DateTime
from flask import Flask, request, jsonify, make_response   
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
#import uuid 
import jwt
from datetime import datetime
from functools import wraps
from flask_cors import CORS
#import json

app = Flask(__name__) 
CORS(app)
#cors = CORS(app, resources={r"/api/*": {"origins": "*"}})

app.config['SECRET_KEY']='f3n1ls3cr3t'
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///F:\LeaveTracker\LTApi\LTdatabase.db' 
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True 

db = SQLAlchemy(app)   

#ORM class for SQL Alchemy and Sqlite db entity for users table
class users(db.Model):  
  id = db.Column(db.Integer, primary_key=True)
  email = db.Column(db.Text)  
  name = db.Column(db.Text)
  password = db.Column(db.Text)
  role = db.Column(db.Text)

#ORM class for SQL Alchemy and Sqlite db entity for leave_request table
class leave_request(db.Model):  
  id = db.Column(db.Integer, primary_key=True)
  fk_userid = db.Column(db.Integer)  
  from_date = db.Column(db.DateTime)
  to_date = db.Column(db.DateTime)
  leave_reason = db.Column(db.Text)
  status = db.Column(db.Text)
  approved_byid = db.Column(db.Integer)
  approved_date = db.Column(db.DateTime)
  approval_comments = db.Column(db.Text)
  submitted_id = db.Column(db.Integer)

#used for authorization of the token
def token_required(f):  
    @wraps(f)  
    def decorator(*args, **kwargs):
       token = None 
       if 'x-access-tokens' in request.headers:  
          token = request.headers['x-access-tokens'] 

       if not token:  
          return jsonify({'message': 'a valid token is missing'})   
       
       try:  
          data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
          current_user = users.query.filter_by(email=data['email']).first()
       except:  
          return jsonify({'message': 'token is invalid'})  

       return f(current_user, *args,  **kwargs)  
    return decorator 

#creating new user api
@app.route('/createuser', methods=['GET', 'POST'])
def create_user():  
 data = request.get_json()  

 #generating hashed password
 hashed_password = generate_password_hash(data['password'], method='sha256')
 
 new_user = users(email=data['email'], name=data['name'], password=hashed_password, role=data['role']) 
 db.session.add(new_user)  
 db.session.commit()    

 return jsonify({'message': 'user created successfully'})   

#login api to authenticate and authorize user. also will generate token 
@app.route('/login', methods=['GET', 'POST'])  
def login_user(): 
  #auth = request.authorization 
  auth=request.get_json() 
  print(auth)  

  if not auth or not auth['username'] or not auth['password']:  
     return make_response('user can not be verified', 401, {'WWW.Authentication': '"login required"'})    

  user = users.query.filter_by(email=auth['username']).first()   
     
  if check_password_hash(user.password, auth['password']):  
     token = jwt.encode({"email": user.email}, app.config['SECRET_KEY'], algorithm="HS256")
     return jsonify({'token' : token,'name':user.name,'email':user.email,'role':user.role}) 

  return make_response('user can not be verified',  401, {'WWW.Authentication': 'Basic realm: "login required"'})

#api to get all the registered users
@app.route('/user', methods=['GET'])
@token_required
def get_all_users(current_user):  
   
   lstusers = users.query.all() 
   result = []   

   for user in lstusers:   
       user_data = {}   
       user_data['id'] = user.id  
       user_data['name'] = user.name 
       user_data['password'] = user.password
       user_data['email'] = user.email
       user_data['role'] = user.role 
       
       result.append(user_data)   

   return jsonify({'users': result})  

#api to get all the managers
@app.route('/manager', methods=['GET'])
@token_required
def get_all_manager(current_user):  
   
   lstusers = users.query.filter_by(role='Manager').all() 
   result = []   

   for user in lstusers:   
       user_data = {}   
       user_data['id'] = user.id  
       user_data['name'] = user.name 
       user_data['password'] = user.password
       user_data['email'] = user.email
       user_data['role'] = user.role 
       
       result.append(user_data)   

   return jsonify({'users': result})  

#api to get user by id
@app.route('/user/<id>', methods=['GET'])
@token_required
def get_byid(current_user,id):
    lstusers = users.query.filter_by(id=int(id)).first() 
    print(lstusers)

    result = []   
       
    user_data = {}   
    user_data['id'] = lstusers.id  
    user_data['name'] = lstusers.name 
    user_data['password'] = lstusers.password
    user_data['email'] = lstusers.email
    user_data['role'] = lstusers.role 
    
    result.append(user_data)

    return jsonify(user_data)

#api to update user
@app.route('/user', methods=['POST'])
@token_required
def update_user(current_user):  
    objuser=request.get_json()  
    user = users.query.filter_by(id=objuser['id']).first()
    if not user:   
       return jsonify({'message': 'user does not exist'}) 
    #generating hashed password
    change_password=False
    if objuser['password'] != "" or objuser['password'] != None:
      hashed_password = generate_password_hash(objuser['password'], method='sha256')
      change_password = True
    user.name = objuser['name']
    user.email = objuser['email']
    user.role = objuser['role']
    if change_password:
      user.password = hashed_password
    db.session.commit()   

    return jsonify({'message': 'user updated successfully'})

#api to delete user
@app.route('/user/<id>', methods=['DELETE'])
@token_required
def delete_user(current_user, id):  
    user = users.query.filter_by(id=id).first()   
    if not user:   
       return jsonify({'message': 'User does not exist'})   

    db.session.delete(user)  
    db.session.commit()   

    return jsonify({'message': 'user deleted'})

#creating new leave request api
@app.route('/createleaverequest', methods=['POST'])
@token_required
def create_LR(current_user):  
 data = request.get_json()  
 
 print(data['from_date'])
#  var_from_date = datetime.strptime(data['from_date'], '%Y-%d-%m').date()
 var_from_date = data['from_date']
 print(var_from_date)
#  var_to_date = datetime.strptime(data['to_date'], '%Y-%d-%m').date()
 var_to_date = data['to_date']
 var_from_date_time = str(var_from_date) + ' 00:00:00.000000'
 print(var_from_date_time)
 var_to_date_time =  str(var_to_date) + ' 00:00:00.000000'
 exists = leave_request.query.filter_by(fk_userid=(data['fk_userid']), from_date=var_from_date_time,to_date=var_to_date_time).first()
 var_from_date_new = datetime.strptime(var_from_date, '%Y-%m-%d').date()
 var_to_date_new = datetime.strptime(var_from_date, '%Y-%m-%d').date()
 if exists:   
      return make_response('Leave request already exists for this user for the same day',  0,{'WWW.Authentication': 'Basic realm: "login required"'})
      return jsonify({'message': 'Leave request already exists for this user for the same day'}) 
 new_lr = leave_request(fk_userid=int(data['fk_userid']), from_date=(var_from_date_new), to_date=(var_to_date_new), leave_reason=data['leave_reason'],status=data['status'],approved_byid=None,approved_date=None,submitted_id=current_user.id) 
 db.session.add(new_lr)  
 db.session.commit()    

 return jsonify({'message': 'leave request submitted successfully'})  


#api to leave request by submitter
@app.route('/leaverequest', methods=['GET'])
@token_required
def get_lrbyuserid(current_user):
   lstrequest = leave_request.query.filter_by(submitted_id=int(current_user.id)).all() 
   #print(lstrequest)

   result = []   

   for objlr in lstrequest:   
      lr_data = {}   
      lr_data['id'] = objlr.id  
      lr_data['fk_userid'] = objlr.fk_userid 
      lr_data['from_date'] = objlr.from_date
      lr_data['to_date'] = objlr.to_date
      lr_data['leave_reason'] = objlr.leave_reason 
      lr_data['status'] = objlr.status 
      lr_data['approved_byid'] = objlr.approved_byid 
      lr_data['approved_date'] = objlr.approved_date 
      lr_data['approval_comments'] = objlr.approval_comments
      lr_data['submitted_id'] = objlr.submitted_id
      result.append(lr_data) 

   return jsonify({'lrData': result})  

#api to leave request for approver
@app.route('/leaverequestforapproval', methods=['GET'])
@token_required
def get_lr_by_approver_id(current_user):
   lstrequest = leave_request.query.filter_by(fk_userid=int(current_user.id)).all() 
   #print(lstrequest)

   result = []   

   for objlr in lstrequest:   
      lr_data = {}   
      lr_data['id'] = objlr.id  
      lr_data['fk_userid'] = objlr.fk_userid 
      lr_data['from_date'] = objlr.from_date
      lr_data['to_date'] = objlr.to_date
      lr_data['leave_reason'] = objlr.leave_reason 
      lr_data['status'] = objlr.status 
      lr_data['approved_byid'] = objlr.approved_byid 
      lr_data['approved_date'] = objlr.approved_date 
      lr_data['approval_comments'] = objlr.approval_comments
      lr_data['submitted_id'] = objlr.submitted_id
      result.append(lr_data) 

   return jsonify({'lrData': result}) 

#api to approveleave request
@app.route('/leaverequestapprove', methods=['POST'])
@token_required
def approve_leave_request(current_user):  
    objLr=request.get_json()  
    lrDetail = leave_request.query.filter_by(id=objLr['id']).first()
    if not lrDetail:   
       return jsonify({'message': 'leave request does not exist'}) 
    lrDetail.status = objLr['status']
    lrDetail.approval_comments = objLr['approval_comments']
    lrDetail.approved_byid = current_user.id
    lrDetail.approved_date = datetime.today()#datetime.strptime(datetime.today(), '%Y-%d-%m').date()
    db.session.commit()   

    return jsonify({'message': 'leave request updated successfully'})

#api to delete leave request
@app.route('/leaverequest/<id>', methods=['DELETE'])
@token_required
def delete_leave_request(current_user, id):  
    user = leave_request.query.filter_by(id=id).first()   
    if not user:   
       return jsonify({'message': 'Leave Request does not exist'})   

    db.session.delete(user)  
    db.session.commit()   

    return jsonify({'message': 'Leave Request deleted'})

if  __name__ == '__main__':  
     app.run(debug=True)